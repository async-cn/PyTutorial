from sys import exit
from traceback import print_exc

def fatal(msg, traceback:bool=False) -> None:
    print("\033[91m"+str(msg)+"\033[0m")
    if traceback: print_exc()
    exit(1)