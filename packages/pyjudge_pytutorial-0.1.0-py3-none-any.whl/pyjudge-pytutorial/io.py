import json

def load_json(path:str) -> dict:
    with open(path, mode='r', encoding='utf-8') as f:
        return json.load(f)

def load_code_from_ipynb(path:str) -> str:
    return ''.join(load_json(path)['cells'][0]['source'])

def generate_pyscript(input_path:str, output_path:str) -> None:
    with open(output_path, mode='w', encoding='utf-8') as f:
        f.write(load_code_from_ipynb(input_path))