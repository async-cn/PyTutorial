import os
from sys import argv
from pyjudge.judge import quick_judge, display_judge_result
from .utils import fatal
from .io import load_json, generate_pyscript

if len(argv) <= 1:
    print("PyJudge-PyTutorial v0.1.0")
else:
    if not os.path.exists(argv[1]):
        fatal(f"路径不存在: {argv[1]}")
        exit(0)

    config_path = os.path.join(argv[1], "judge.json")
    if not os.path.exists(config_path):
        fatal(f"测试配置文件不存在: {config_path}")

    config = load_json(config_path)
    name = config["program"] if "program" in config else config["name"]
    program_path_relative = name + ".py"
    program_path = os.path.join(argv[1], program_path_relative)

    try:
        generate_pyscript(os.path.join(argv[1], name + ".ipynb"), program_path)
    except Exception as e:
        fatal(f"从 {name + ".ipynb"} 加载代码失败: {str(e)}", True)

    if not os.path.exists(program_path):
        fatal(f"测试程序不存在: {program_path}")

    result = quick_judge(program_path, config_path, argv[1])
    display_judge_result(result, len(config['nodes']), config)